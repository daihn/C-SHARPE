﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 初始化一副牌
{
    class Program
    {
        static void Main(string[] args)
        {
        NextLoop:
            // 一副新牌
            int[] card = CardInit.VirginCard();

            // 洗牌并得到新的牌序
            Dictionary<int, cardData> dic = new Dictionary<int, cardData>();
            Dictionary<int, cardData> result = new Dictionary<int, cardData>();
            Shuffle.RandomSort(card, ref dic, ref result);

            // 显示手牌
            Console.WriteLine("拿到的牌：");
            HandCard.Init(card, result, 1);

            Console.WriteLine("叫地主？(Y/N)");
            string str = Console.ReadLine();
            if(str == "Y")
            {
                Console.WriteLine("底牌：");
                HandCard.Init(card, result, 0);
            }
            else if(str == "N")
            {
                Console.WriteLine("重新开始");
                Console.Clear();
                goto NextLoop;
            }
            else
            {
                Console.WriteLine("输入错误，看下说明啊！！！");
            }

            Console.WriteLine("叫地主？");

            Console.WriteLine("未完待续。。。");

            Console.ReadKey();
        }
    }
}
