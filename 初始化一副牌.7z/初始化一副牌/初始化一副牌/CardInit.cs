﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 初始化一副牌
{
    public  struct cardData
    {
        public string color;
        public string point;
    };

    public struct MyMap
    {
        public int key;
        public int value;
    };

    class CardInit
    {
        // 拿出一副新牌
        public static int[] VirginCard()
        {
            int[] card = new int[54];

            // 一副有顺序的牌
            for (int i = 0; i < 54; i++)
            {
                card[i] = i;
            }
            return card;
        }

        // 新牌
        public static void NewCard(int[] card, ref Dictionary<int, cardData> dic,ref Dictionary<int, cardData> result)
        {
            string[] color = { "红桃", "方块", "黑桃", "梅花", "小王", "大王" };
            string[] point = { "A", "2", "3", "4", "5", "6",
                               "7", "8", "9", "10", "J", "Q",
                               "K", ""};

            dic = new Dictionary<int, cardData>();


            for (int i = 0; i < 54; i++)
            {
                cardData data = new cardData();
                data.color = card[i] > 51 ? (card[i] == 52 ? color[4] : color[5]) :
                           color[card[i] / 13];
                data.point = card[i] > 51 ? point[13] : point[card[i] % 13];

                dic.Add(card[i], data);
            }

            SortNewCard(ref card,ref dic,ref result);
        }

        // 排序
        private static void SortNewCard(ref int[] card,ref Dictionary<int, cardData> dic, ref Dictionary<int, cardData> result)
        {
            // 建立映射数组
            MyMap[] newCard = new MyMap[54];
            CreateMyMap(dic, ref newCard);

            // 对映射数组进行排序
            Sort(ref newCard);

            // 映射回来，排序成功
            GetNewDic(ref card,newCard, ref dic, ref result);
        }

        // 创造一副被映射的牌
        private static void CreateMyMap(Dictionary<int, cardData> dic,ref MyMap[] arr)
        {
            int count = 0;
            foreach(KeyValuePair<int, cardData> item in dic)
            {
                arr[count].key = item.Key;
                arr[count++].value = item.Key > 51 ? item.Key :
                                    ((item.Key - 2) % 13 < 0 ?
                                     (item.Key - 2) % 13 + 13 :
                                     (item.Key - 2) % 13); 
            }
        }

        // 单副牌排序
        private static void OneSort(ref MyMap[] array, int num)
        {
            for (int i = (num - 1) * 17 ; i < 17 - 1; i++)
            {
                for (int j = 0; j < 17 - i - 1; j++)
                {
                    if (array[j].value > array[j + 1].value)
                    {
                        MyMap temp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temp;
                    }
                }
            }
        }

        // 三副牌进行各自排序
        private static void Sort(ref MyMap[] array)
        {
            //
            // 三副牌各自排序
            //

            // 第一副牌进行排序
            OneSort(ref array, 1);

            // 第二副牌进行排序
            OneSort(ref array, 2);

            // 第三副牌进行排序
            OneSort(ref array, 3);
        }

        // 获取排序好的牌
        private static void GetNewDic(ref int[] card, MyMap[] newCard, ref Dictionary<int, cardData> dic, ref Dictionary<int, cardData> result)
        {
            for(int i = 0; i < 54; i++)
            {
                // 获取键值
                int key = newCard[i].key;

                // 从小到大进行排序

               foreach(KeyValuePair<int, cardData> item in dic)
               {
                    if(item.Key == key)
                    {
                        result.Add(key, item.Value);
                        card[i] = key;
                    }
               }

            }
        }
    }
}
