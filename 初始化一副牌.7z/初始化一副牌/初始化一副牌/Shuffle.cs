﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 初始化一副牌
{
    class Shuffle
    {
        public static void RandomSort(int[] card, ref Dictionary<int, cardData> dic, ref Dictionary<int, cardData> result)
        {
            // 洗牌
            Random r = new Random();

            for (int i = 0; i < 54; i++)
            {
                int randTemp = (int)(54 * r.NextDouble());

                int temp = card[i];
                card[i] = card[randTemp];
                card[randTemp] = temp;
            }
            // 得到的新牌
            CardInit.NewCard(card,ref dic, ref result);
        }
    }
}
