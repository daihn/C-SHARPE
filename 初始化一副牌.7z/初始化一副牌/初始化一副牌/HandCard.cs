﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 初始化一副牌
{
    class HandCard
    {
        public static void Init(int[] card, Dictionary<int, cardData> dic, int num)
        {
            int t = 0;
            switch(num)
            {
                    case 1:
                    {
                        for(;t < 17; t++)
                        {
                            Console.Write(dic[card[t]].color + dic[card[t]].point + "  ");
                        }
                        Console.WriteLine();
                        break;
                    }
                case 2:
                    {
                        for (t = 17; t < 34; t++)
                        {
                            Console.Write(dic[card[t]].color + dic[card[t]].point + "  ");
                        }
                        Console.WriteLine();
                        break;
                    }
                case 3:
                    {
                        for (t = 34; t < 51; t++)
                        {
                            Console.Write(dic[card[t]].color + dic[card[t]].point + "  ");
                        }
                        Console.WriteLine();
                        break;
                    }
                default:
                    {
                        for(t = 51; t < 54; t++)
                        {
                            Console.Write(dic[card[t]].color + dic[card[t]].point + "  ");
                        }
                        Console.WriteLine();
                        break;
                    }
            }
            Console.WriteLine();
        } 
    }
}
