﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace UpdateDBData
{
    class Program
    {
        static void Main(string[] args)
        {

            //var value = ConfigurationManager.AppSettings["DBConnectString"];
            //Console.WriteLine("hello world");
            //Console.ReadKey();

            String connsql = "server=tcp:192.168.56.10;database=EMSDB;Persist Security Info=false;User=sa;Password=zxcvbASDFG123;MultipleActiveResultSets=true"; // 数据库连接字符串,database设置为自己的数据库名，以Windows身份验证

            try
            {
                using (SqlConnection conn = new SqlConnection())
                {
                    conn.ConnectionString = connsql;
                    conn.Open(); // 打开数据库连接
                    Console.Write(conn.State.ToString());
                    //UPDATE 表名称 SET 列名称 = 新值 WHERE 列名称 = 某值
                    String sqlStr = "SELECT * FROM [EMSDB].[dbo].[T_ROLES]"; // 查询语句


                    /*Select
                    SqlDataAdapter sda = new SqlDataAdapter(sqlStr, conn);
                    DataSet ds = new DataSet();
                    sda.Fill(ds);
                    //string val = ds.Table[0].Rows[第几行]["列名"].ToString();
                    string val = ds.Tables[0].Rows[3]["RoleId"].ToString();
                    Console.WriteLine(val);
                    */


                    /*Update,Insert,Delete
                    SqlCommand cmd = new SqlCommand( sqlStr, conn);
                    cmd.Connection = conn;
                    cmd.CommandText = sqlStr;
                    cmd.CommandType = CommandType.Text;
                    int i = Convert.ToInt32(cmd.ExecuteNonQuery());
                    */
                    //int i = cmd.ExecuteNonQuery();//执行SQL语句

                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("错误信息：" + ex.Message, "出现错误");
            }

        }
    }
}
