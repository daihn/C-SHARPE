﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UpdateDBData
{
    public class DBOperation
    {

        //public SqlConnection m_EMSDBConnection;
        //public SqlConnection m_SWUserDBConnection;
        //public SqlConnection m_SWAServiceDBConnection;


        public bool ConnectDB()
        {
            String connsql = "server=tcp:192.168.56.10;database=EMSDB;Persist Security Info=false;User=sa;Password=zxcvbASDFG123;MultipleActiveResultSets=true"; // 数据库连接字符串,database设置为自己的数据库名，以Windows身份验证

            try
            {
                using (SqlConnection conn = new SqlConnection())
                {
                    conn.ConnectionString = connsql;
                    conn.Open(); // 打开数据库连接
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("错误信息：" + ex.Message, "出现错误");
                return false;
            }

            return true;
        }

    }
}
