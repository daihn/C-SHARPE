﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace UpdateDBData
{
    public class AppProperties
    {
        // 获取EMS信息
        public static string GetEMSDBInfo()
        {
            return GetValueFromAppConfig("DBConnectString");
        }

        // 获取SWUserDB信息
        public static string GetSWUserDBInfo()
        {
            return GetValueFromAppConfig("UDBConnectString");
        }

        // 获取SWAService信息
        public static string GetSWAServiceDBInfo()
        {
            return GetValueFromAppConfig("SDBConnectString");
        }

        // 获取XML信息
        private static string GetValueFromAppConfig(string keyName)
        {
            return ConfigurationManager.AppSettings[keyName];
        }
    }
}
