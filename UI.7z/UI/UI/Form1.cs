﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class Form1 : Form
    {
        bool isRightState = true;

        public Form1()
        {
            InitializeComponent();
        }

        private bool IsDigital(string str)
        {
            for(int i=0; i<str.Length; i++)
            {
                int pointCount = 0;
                if(str[i] >= '0' && str[i] <= '9' )
                {
                    continue;
                }
                else if(str[i] == '.')
                {
                    if(pointCount > 1)
                    {
                        return false;
                    }
                    else
                    {
                        pointCount++;
                    }
                }
                else
                {
                    return false;
                }
            }

            return true;
        }

        private bool IsInputLegal(ref string errorInfo)
        {
            string textBox1 = this.textBox1.Text;
            string textBox2 = this.textBox2.Text;
            bool isNormalState = true;

            if (!this.IsDigital(textBox1) || !this.IsDigital(textBox2))
            {
                errorInfo = "输入存在非数字的值";
                isNormalState = false;
            }
            else if (string.IsNullOrWhiteSpace(textBox1) || string.IsNullOrWhiteSpace(textBox2))
            {
                errorInfo = "未输入要运算的值";
                isNormalState = false;
            }

            if (this.comboBox1.Text == "")
            {
                if (string.IsNullOrWhiteSpace(errorInfo) == true)
                {
                    errorInfo = "未选择对应的运算";
                }
                else
                {
                    errorInfo = string.Join("，", errorInfo, "并且未选择对应的运算");
                }

                isNormalState = false;
            }
            return isNormalState;
        }

        delegate double NumChanger(double x, double y);

        double AddNum(double x, double y)
        {
            return num = x + y;
        }

        double SubNum(double x, double y)
        {
            return num = x - y;
        }

        double MulNum(double x, double y)
        {
            return num = x * y;
        }

        double DivNum(double x, double y)
        {
            if(y == 0.0)
            {
                MessageBox.Show("除数为零", "警告", MessageBoxButtons.OK,
                MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);

                isRightState = false;
            }
            else
            {
                num = x / y;
            }
            return num;  
        }

        double ComplementationNum(double x, double y)
        {
            if((int)x == x && (int)y == y)
            {
                int tempX = Convert.ToInt32(x);
                int tempY = Convert.ToInt32(y);
                int temp = tempX % tempY;
                num = Convert.ToDouble(temp);
            }
            else
            {
                MessageBox.Show("除数不是整数", "警告", MessageBoxButtons.OK,
                MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);

                isRightState = false;
            }

            

            return num;
        }


        private double DealNum()
        {
            char ch = this.comboBox1.Text[0];

            try
            {
                string strAdd1 = this.textBox1.ToString();
                string strAdd2 = this.textBox2.ToString();

                string a = strAdd1;
                double add1 = Convert.ToDouble(strAdd1.Substring(36));
                double add2 = Convert.ToDouble(strAdd2.Substring(36));
            
                double result = 0;

                NumChanger add = new NumChanger(AddNum);
                NumChanger sub = new NumChanger(SubNum);
                NumChanger mul = new NumChanger(MulNum);
                NumChanger div = new NumChanger(DivNum);
                NumChanger com = new NumChanger(ComplementationNum);

                switch (ch)
                {
                    case '+':
                        add(add1, add2);
                        break;
                    case '-':
                        sub(add1, add2);
                        break;
                    case '*':
                        mul(add1, add2);
                        break;
                    case '/':
                        div(add1, add2);
                        break;
                    case '%':
                        com(add1, add2);
                        break;
                    default:
                        break;
                }

                result = num;
                num = 0.0;

                return result;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                return 0;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string errorInfo = "";
            bool isNormalState = IsInputLegal(ref errorInfo);

            if (isNormalState == false)
            {
                MessageBox.Show(errorInfo, "错误", MessageBoxButtons.OK,
                MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);

                return;
            }

            double result = DealNum();

            if(isRightState == false)
            {
                isRightState = true;
                return;
            }

            this.textBox3.Text = string.Format("{0:N2}", result);   
        }

        private double num = 0.0;

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.label3.Text = "日期";
        }
    }
}
