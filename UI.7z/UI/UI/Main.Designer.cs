﻿using System.Drawing;

namespace UI
{
    partial class Main
    {
        private string userName = "root";
        private string passWord = "123456";
        private ValidCode validCode;

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.user_text = new System.Windows.Forms.TextBox();
            this.pwd_text = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtValidCode = new System.Windows.Forms.TextBox();
            this.login_bn = new GButton.GZXButton();
            this.picValidCode = new System.Windows.Forms.PictureBox();
            this.regist_bn = new GButton.GZXButton();
            ((System.ComponentModel.ISupportInitialize)(this.picValidCode)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // user_text
            // 
            resources.ApplyResources(this.user_text, "user_text");
            this.user_text.Name = "user_text";
            // 
            // pwd_text
            // 
            resources.ApplyResources(this.pwd_text, "pwd_text");
            this.pwd_text.Name = "pwd_text";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtValidCode
            // 
            resources.ApplyResources(this.txtValidCode, "txtValidCode");
            this.txtValidCode.Name = "txtValidCode";
            // 
            // login_bn
            // 
            this.login_bn.BackColor = System.Drawing.Color.DarkTurquoise;
            resources.ApplyResources(this.login_bn, "login_bn");
            this.login_bn.Name = "login_bn";
            this.login_bn.UseVisualStyleBackColor = false;
            this.login_bn.Click += new System.EventHandler(this.login_bn_Click);
            // 
            // picValidCode
            // 
            resources.ApplyResources(this.picValidCode, "picValidCode");
            this.picValidCode.Name = "picValidCode";
            this.picValidCode.TabStop = false;
            validCode = new ValidCode(4, ValidCode.CodeType.Numbers);
            this.picValidCode.Image = Bitmap.FromStream(validCode.CreateCheckCodeImage());
            this.picValidCode.Click += new System.EventHandler(this.picValidCode_Click);
            // 
            // regist_bn
            // 
            this.regist_bn.BackColor = System.Drawing.Color.DarkTurquoise;
            resources.ApplyResources(this.regist_bn, "regist_bn");
            this.regist_bn.Name = "regist_bn";
            this.regist_bn.UseVisualStyleBackColor = false;
            this.regist_bn.Click += new System.EventHandler(this.regist_bn_Click);
            // 
            // Main
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::UI.Properties.Resources.Main;
            this.Controls.Add(this.picValidCode);
            this.Controls.Add(this.txtValidCode);
            this.Controls.Add(this.regist_bn);
            this.Controls.Add(this.login_bn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pwd_text);
            this.Controls.Add(this.user_text);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Main";
            ((System.ComponentModel.ISupportInitialize)(this.picValidCode)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox user_text;
        private System.Windows.Forms.TextBox pwd_text;
        private System.Windows.Forms.Label label3;
        private GButton.GZXButton login_bn;
        private System.Windows.Forms.TextBox txtValidCode;
        private System.Windows.Forms.PictureBox picValidCode;
        private GButton.GZXButton regist_bn;
    }
}