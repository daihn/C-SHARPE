﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void picValidCode_Click(object sender, EventArgs e)
        {
            validCode = new ValidCode(4,ValidCode.CodeType.Numbers);
            this.picValidCode.Image = Bitmap.FromStream(validCode.CreateCheckCodeImage());
        }

        private void login_bn_Click(object sender, EventArgs e)
        {
            if (this.user_text.ToString().Substring(36) != userName
                || this.pwd_text.ToString().Substring(36) != passWord)
            {
                MessageBox.Show("用户名或者密码错误", "错误信息", MessageBoxButtons.OK,
                MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                validCode = new ValidCode(4, ValidCode.CodeType.Numbers);
                this.picValidCode.Image = Bitmap.FromStream(validCode.CreateCheckCodeImage());
                return;
            }
            if (!this.txtValidCode.Text.Equals(validCode.CheckCode))
            {
                validCode = new ValidCode(4, ValidCode.CodeType.Numbers);
                this.picValidCode.Image = Bitmap.FromStream(validCode.CreateCheckCodeImage());
                MessageBox.Show(" 请输入正确的验证码!", this.Text);
                this.txtValidCode.Focus();
                this.txtValidCode.Text = "";
                this.user_text.Text = "";
                this.pwd_text.Text = "";

                return;
            }
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void regist_bn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("功能暂时没有开放");
        }
    }
}
