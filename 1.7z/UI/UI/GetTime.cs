﻿using System;
using System.Windows.Forms;

namespace UI
{
    class Class1
    {
        System.Windows.Forms.Timer timer;
        Label label;
        public Class1(Label label)
        {
            this.label = label;
            label.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            timer = new Timer();
            timer.Tick += timer_Tick;
            timer.Interval = 1000;
            timer.Enabled = true;
        }


        void timer_Tick(object sender, EventArgs e)
        {
            label.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }
    }
}